
import React from 'react';
 import MessagingUI from './components/MessagingUI';
 
function App() {
  return (
    <div>
       <MessagingUI />
    </div>
  );
}

export default App;

